import os, asyncio
from aiogram import Bot, Dispatcher, types
from aiogram.filters import CommandStart
from aiogram.types import WebAppInfo, InlineKeyboardMarkup, InlineKeyboardButton
BOT_TOKEN=os.environ["BOT_TOKEN"]; WEBAPP_URL=os.environ["WEBAPP_URL"]; dp=Dispatcher()
@dp.message(CommandStart())
async def start(m:types.Message):
    kb=InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="🎰 Играть",web_app=WebAppInfo(url=WEBAPP_URL))]])
    await m.answer("Добро пожаловать в REEL RUSH 🎰",reply_markup=kb)
async def main(): await dp.start_polling(Bot(BOT_TOKEN))
if __name__=="__main__": asyncio.run(main())


@dp.message(Command("play"))
async def play(message: Message):
    keyboard = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text="🎰 ИГРАТЬ",
                    web_app=WebAppInfo(url=WEBAPP_URL)
                )
            ]
        ]
    )
    await message.answer(
        "🎰 REEL RUSH\n\nГотов крутить барабаны?",
        reply_markup=keyboard
    )
